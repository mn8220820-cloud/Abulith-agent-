# بناء APK عبر GitHub Actions

1. أنشئ مستودع GitHub جديد.
2. ارفع محتويات هذا المشروع إلى المستودع، مع مجلد `.github/workflows/`.
3. ادخل إلى تبويب **Actions**.
4. اختر **Build AbuLaith Agent APK**.
5. اضغط **Run workflow**.
6. بعد انتهاء البناء افتح التشغيل الناجح ثم قسم **Artifacts**.
7. نزّل `AbuLaithAgent-debug-apk` وفك الضغط لتحصل على `app-debug.apk`.
8. ثبّت APK على هاتف Android.

## إصدار تلقائي عند إنشاء Tag

عند دفع Tag باسم مثل `v1.0.0` سيبني GitHub Actions الـAPK وينشئ GitHub Release ويضع APK وملف SHA-256 داخل الإصدار.

## ملاحظة عن Backend

بناء الـAPK لا يحتاج `OPENAI_API_KEY` لأن المفتاح يجب أن يبقى على الخادم. بعد تثبيت التطبيق، شغّل `backend/` على خادم HTTPS أو جهاز داخل الشبكة، ثم ضع عنوانه في إعدادات التطبيق.
