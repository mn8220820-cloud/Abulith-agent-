
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const MODEL = "gpt-5.6-luna";

const tools = [
  {
    type: "function",
    name: "open_url",
    description: "طلب فتح رابط في متصفح الهاتف. لا ينفذ مباشرة؛ يعاد للمستخدم كموافقة مطلوبة.",
    parameters: {
      type: "object",
      properties: { url: { type: "string", description: "رابط http أو https" } },
      required: ["url"],
      additionalProperties: false
    },
    strict: true
  },
  {
    type: "function",
    name: "share_text",
    description: "طلب فتح شاشة مشاركة Android بنص محدد. لا ينفذ مباشرة؛ يحتاج موافقة المستخدم.",
    parameters: {
      type: "object",
      properties: { text: { type: "string" } },
      required: ["text"],
      additionalProperties: false
    },
    strict: true
  },
  {
    type: "function",
    name: "create_text_file",
    description: "طلب إنشاء ملف نصي محلي على الهاتف. لا ينفذ مباشرة؛ يحتاج موافقة المستخدم.",
    parameters: {
      type: "object",
      properties: {
        filename: { type: "string" },
        content: { type: "string" }
      },
      required: ["filename", "content"],
      additionalProperties: false
    },
    strict: true
  }
];

app.get("/health", (_req, res) => res.json({ ok: true, version: "1.0.0" }));

app.post("/api/agent", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "message is required" });

    const history = Array.isArray(req.body?.history) ? req.body.history : [];
    const input = [
      {
        role: "system",
        content:
          "أنت أبو ليث Agent. حافظ على سياق المحادثة. يمكنك اقتراح أدوات Android، لكن لا تعتبر أي إجراء خارجي منفذاً حتى يوافق المستخدم صراحة. عند طلب فتح رابط أو مشاركة نص أو إنشاء ملف، استخدم الأداة المناسبة. لا تستخدم الأدوات لتنفيذ معاملات مالية أو رسائل حساسة أو حذف بيانات."
      },
      ...history.slice(-20).map(x => ({
        role: x.role === "assistant" ? "assistant" : "user",
        content: String(x.text || "")
      })),
      { role: "user", content: message }
    ];

    const response = await client.responses.create({
      model: MODEL,
      tools: [{ type: "web_search" }, ...tools],
      tool_choice: "auto",
      input
    });

    const calls = (response.output || []).filter(x => x.type === "function_call");
    const proposals = calls.map(c => ({
      callId: c.call_id,
      name: c.name,
      arguments: JSON.parse(c.arguments || "{}")
    }));

    res.json({
      output: response.output_text || (proposals.length ? "لدي إجراء جاهز ويحتاج موافقتك." : "لم يُرجع الوكيل نصاً."),
      requiresApproval: proposals.length > 0,
      actions: proposals
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err?.message || "server error" });
  }
});

app.listen(process.env.PORT || 8080, () => {
  console.log(`AbuLaith Agent backend listening on ${process.env.PORT || 8080}`);
});
