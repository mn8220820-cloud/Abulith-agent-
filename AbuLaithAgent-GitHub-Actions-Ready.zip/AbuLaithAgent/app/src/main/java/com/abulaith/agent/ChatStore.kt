
package com.abulaith.agent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

class ChatStore(context: Context) {
    private val prefs = context.getSharedPreferences("chat_store", Context.MODE_PRIVATE)
    fun all(): MutableList<ChatMessage> {
        val arr = JSONArray(prefs.getString("items", "[]") ?: "[]")
        val out = mutableListOf<ChatMessage>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out += ChatMessage(o.getString("id"), o.getString("role"), o.getString("text"), o.optLong("timestamp"))
        }
        return out
    }
    fun add(role: String, text: String) {
        val list = all()
        list += ChatMessage(role = role, text = text)
        val arr = JSONArray()
        list.takeLast(100).forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("role", it.role); put("text", it.text); put("timestamp", it.timestamp)
            })
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
    fun clear() = prefs.edit().remove("items").apply()
}
