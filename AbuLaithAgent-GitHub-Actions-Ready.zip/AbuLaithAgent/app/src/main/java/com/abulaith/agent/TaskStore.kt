package com.abulaith.agent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class AgentTask(
    val id: String = UUID.randomUUID().toString(),
    var title: String,
    var schedule: String, // ONCE or DAILY
    var enabled: Boolean = true,
    var lastResult: String = "",
    var createdAt: Long = System.currentTimeMillis()
)

class TaskStore(context: Context) {
    private val prefs = context.getSharedPreferences("tasks", Context.MODE_PRIVATE)

    fun all(): MutableList<AgentTask> {
        val raw = prefs.getString("items", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = mutableListOf<AgentTask>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out += AgentTask(
                id = o.getString("id"),
                title = o.getString("title"),
                schedule = o.getString("schedule"),
                enabled = o.optBoolean("enabled", true),
                lastResult = o.optString("lastResult", ""),
                createdAt = o.optLong("createdAt", System.currentTimeMillis())
            )
        }
        return out
    }

    fun save(task: AgentTask) {
        val list = all()
        val index = list.indexOfFirst { it.id == task.id }
        if (index >= 0) list[index] = task else list.add(0, task)
        persist(list)
    }

    fun delete(id: String) {
        persist(all().filterNot { it.id == id })
    }

    fun setEnabled(id: String, enabled: Boolean) {
        all().firstOrNull { it.id == id }?.let {
            it.enabled = enabled
            save(it)
        }
    }

    fun setResult(id: String, result: String) {
        all().firstOrNull { it.id == id }?.let {
            it.lastResult = result
            save(it)
        }
    }

    private fun persist(list: List<AgentTask>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("title", it.title)
                put("schedule", it.schedule)
                put("enabled", it.enabled)
                put("lastResult", it.lastResult)
                put("createdAt", it.createdAt)
            })
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
