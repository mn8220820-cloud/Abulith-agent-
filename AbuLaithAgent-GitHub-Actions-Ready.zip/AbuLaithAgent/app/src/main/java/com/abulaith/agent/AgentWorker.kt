
package com.abulaith.agent

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AgentWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val taskId = inputData.getString("taskId") ?: return@withContext Result.failure()
        val taskText = inputData.getString("taskText") ?: return@withContext Result.failure()
        val baseUrl = inputData.getString("baseUrl") ?: return@withContext Result.failure()
        try {
            val result = AgentApi.run(baseUrl, taskText)
            if (result.actions.isNotEmpty()) {
                val approvals = ApprovalStore(applicationContext)
                result.actions.forEach { approvals.add(it) }
                OperationLogStore(applicationContext).add(
                    OperationLog(action = "background_agent", details = "${result.actions.size} إجراء", status = "أضيف إلى صندوق الموافقات")
                )
            }
            val output = if (result.requiresApproval || result.actions.isNotEmpty()) {
                "يوجد إجراء يحتاج موافقة داخل التطبيق. افتح التطبيق للمراجعة."
            } else result.output
            TaskStore(applicationContext).setResult(taskId, output)
            notify(if (result.requiresApproval) "موافقة مطلوبة" else "اكتملت المهمة", output)
            Result.success()
        } catch (e: Exception) {
            TaskStore(applicationContext).setResult(taskId, "فشل: ${e.message}")
            notify("فشل المهمة", e.message ?: "خطأ غير معروف")
            Result.retry()
        }
    }

    private fun notify(title: String, text: String) {
        val channel = "agent_tasks"
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channel, "مهام الوكيل", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val n = NotificationCompat.Builder(applicationContext, channel)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("أبو ليث Agent — $title")
            .setContentText(text.take(350))
            .setStyle(NotificationCompat.BigTextStyle().bigText(text.take(1000)))
            .setAutoCancel(true).build()
        try { NotificationManagerCompat.from(applicationContext).notify((System.currentTimeMillis() % 100000).toInt(), n) } catch (_: SecurityException) {}
    }
}
