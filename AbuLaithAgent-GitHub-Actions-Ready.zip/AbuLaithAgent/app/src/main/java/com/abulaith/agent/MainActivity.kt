
package com.abulaith.agent

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import java.io.File
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private lateinit var store: TaskStore
    private lateinit var logStore: OperationLogStore
    private lateinit var baseUrlInput: EditText
    private lateinit var dashboard: LinearLayout
    private lateinit var taskList: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var chatStore: ChatStore
    private lateinit var approvalStore: ApprovalStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = TaskStore(this)
        logStore = OperationLogStore(this)
        chatStore = ChatStore(this)
        approvalStore = ApprovalStore(this)
        requestNotificationPermission()
        buildUi()
        refreshDashboard()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
        }

        root.addView(TextView(this).apply {
            text = "🤖 أبو ليث Agent"
            textSize = 26f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 6)
        })

        statusText = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 14)
        }
        root.addView(statusText)

        val tabs = LinearLayout(this)
        val home = Button(this).apply { text = "🏠 الرئيسية"; setOnClickListener { showHome() } }
        val tasks = Button(this).apply { text = "⏰ المهام"; setOnClickListener { showTasks() } }
        val controls = Button(this).apply { text = "⚙️ التحكم"; setOnClickListener { showControls() } }
        val chat = Button(this).apply { text = "💬 محادثة"; setOnClickListener { showChat() } }
        val approvals = Button(this).apply { text = "🛡️ موافقات"; setOnClickListener { showApprovals() } }
        tabs.addView(home, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(chat, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(tasks, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(approvals, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.addView(controls, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(tabs)

        val scroll = ScrollView(this)
        dashboard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 12, 4, 20)
        }
        scroll.addView(dashboard)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun refreshDashboard() {
        statusText.text = "🟢 الوكيل جاهز • ${store.all().count { it.enabled }} مهمة مفعّلة"
        showHome()
    }

    private fun clearDashboard() = dashboard.removeAllViews()

    private fun showHome() {
        clearDashboard()
        addCard("🤖 مركز الوكيل", "من هنا تتحكم في المحادثة والمهام والموافقات والسجل.")
        val run = Button(this).apply {
            text = "💬 افتح المحادثة"
            setOnClickListener { showChat() }
        }
        dashboard.addView(run)
        addCard("⏰ المهام", "${store.all().size} مهمة محفوظة • ${store.all().count { it.enabled }} مفعّلة")
        val tasks = Button(this).apply {
            text = "فتح إدارة المهام"
            setOnClickListener { showTasks() }
        }
        dashboard.addView(tasks)
        addCard("📋 السجل", "${logStore.all().size} عملية مسجلة")
        val logs = Button(this).apply {
            text = "عرض سجل العمليات"
            setOnClickListener { showLogs() }
        }
        dashboard.addView(logs)
        addCard("🛡️ الموافقات", "${approvalStore.all().size} طلب ينتظر المراجعة")
        dashboard.addView(Button(this).apply {
            text = "مراجعة الموافقات"
            setOnClickListener { showApprovals() }
        })
        addCard("🛡️ الحماية", "الأدوات الخارجية تحتاج موافقة صريحة، ويمكن تعطيلها من التحكم.")
        val controls = Button(this).apply {
            text = "إدارة الصلاحيات والإعدادات"
            setOnClickListener { showControls() }
        }
        dashboard.addView(controls)
    }


    private fun showChat() {
        clearDashboard()
        val chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this)
        val messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        chatStore.all().forEach { m ->
            messages.addView(TextView(this).apply {
                text = "${if (m.role == "user") "👤" else "🤖"} ${m.text}"
                textSize = 16f
                setPadding(12, 10, 12, 10)
            })
        }
        scroll.addView(messages)
        chatBox.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val input = EditText(this).apply { hint = "اكتب رسالتك للوكيل..." }
        chatBox.addView(input)
        val row = LinearLayout(this)
        row.addView(Button(this).apply {
            text = "إرسال"
            setOnClickListener {
                val text = input.text.toString().trim()
                if (text.isNotBlank()) {
                    chatStore.add("user", text)
                    input.text.clear()
                    sendChat(text)
                }
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply {
            text = "مسح"
            setOnClickListener { chatStore.clear(); showChat() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        chatBox.addView(row)
        dashboard.addView(chatBox, LinearLayout.LayoutParams(-1, -1))
    }

    private fun sendChat(text: String) {
        val base = getPreferences(Context.MODE_PRIVATE).getString("baseUrl", "http://10.0.2.2:8080") ?: ""
        val history = chatStore.all()
        Thread {
            try {
                val result = AgentApi.run(base, text, history)
                runOnUiThread {
                    chatStore.add("assistant", result.output)
                    if (result.actions.isNotEmpty()) {
                        result.actions.forEach { approvalStore.add(it) }
                        Toast.makeText(this, "تمت إضافة ${result.actions.size} موافقة إلى صندوق الموافقات", Toast.LENGTH_LONG).show()
                    }
                    showChat()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    chatStore.add("assistant", "خطأ: ${e.message}")
                    showChat()
                }
            }
        }.start()
    }

    private fun showApprovals() {
        clearDashboard()
        val pending = approvalStore.all()
        addCard("🛡️ صندوق الموافقات", "${pending.size} إجراء ينتظر موافقتك.")
        if (pending.isEmpty()) {
            addCard("لا توجد موافقات", "عندما يطلب الوكيل إجراءً خارجياً سيظهر هنا.")
            return
        }
        pending.forEach { p ->
            val desc = when (p.action.name) {
                "open_url" -> "فتح: ${p.action.args.optString("url")}"
                "share_text" -> "مشاركة: ${p.action.args.optString("text")}"
                "create_text_file" -> "إنشاء: ${p.action.args.optString("filename")}"
                else -> p.action.name
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12,12,12,12) }
            row.addView(TextView(this).apply { text = "🔧 $desc"; textSize = 16f })
            val buttons = LinearLayout(this)
            buttons.addView(Button(this).apply {
                text = "سماح"
                setOnClickListener {
                    if (isToolAllowed(p.action.name)) {
                        logStore.add(OperationLog(action=p.action.name, details=desc, status="موافق عليه من صندوق الموافقات"))
                        performAction(p.action)
                    } else {
                        logStore.add(OperationLog(action=p.action.name, details=desc, status="مرفوض — الأداة متوقفة"))
                    }
                    approvalStore.remove(p.id)
                    showApprovals()
                }
            }, LinearLayout.LayoutParams(0,-2,1f))
            buttons.addView(Button(this).apply {
                text = "رفض"
                setOnClickListener {
                    logStore.add(OperationLog(action=p.action.name, details=desc, status="مرفوض من صندوق الموافقات"))
                    approvalStore.remove(p.id)
                    showApprovals()
                }
            }, LinearLayout.LayoutParams(0,-2,1f))
            row.addView(buttons)
            dashboard.addView(row)
        }
    }

    private fun showTasks() {
        clearDashboard()
        dashboard.addView(Button(this).apply {
            text = "➕ إضافة مهمة جديدة"
            setOnClickListener { showTaskDialog(null) }
        })
        val tasks = store.all()
        if (tasks.isEmpty()) {
            addCard("لا توجد مهام", "اضغط إضافة مهمة لإنشاء أول مهمة.")
            return
        }
        tasks.forEach { task ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 16, 16, 16)
                background = getDrawable(android.R.drawable.dialog_holo_light_frame)
            }
            box.addView(TextView(this).apply {
                text = "⏰ ${task.title}"
                textSize = 18f
            })
            box.addView(TextView(this).apply {
                text = "الجدولة: ${if (task.schedule == "DAILY") "يومية" else "مرة واحدة"}\nالحالة: ${if (task.enabled) "مفعّلة" else "متوقفة"}\nآخر نتيجة: ${task.lastResult.take(180).ifBlank { "لا توجد نتيجة" }}"
                setPadding(0, 8, 0, 8)
            })
            val row = LinearLayout(this)
            row.addView(Button(this).apply {
                text = "▶ الآن"
                setOnClickListener { enqueue(task, 0) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "✏ تعديل"
                setOnClickListener { showTaskDialog(task) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = if (task.enabled) "⏸ إيقاف" else "▶ تشغيل"
                setOnClickListener {
                    if (task.enabled) cancel(task) else enqueue(task, 1)
                    store.setEnabled(task.id, !task.enabled)
                    refreshDashboard()
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "🗑"
                setOnClickListener {
                    cancel(task)
                    store.delete(task.id)
                    showTasks()
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            box.addView(row)
            dashboard.addView(box)
        }
    }

    private fun showControls() {
        clearDashboard()
        addCard("⚙️ رابط الـBackend", "احفظ عنوان الخادم الذي يتصل به التطبيق.")
        baseUrlInput = EditText(this).apply {
            hint = "http://10.0.2.2:8080"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(getPreferences(Context.MODE_PRIVATE).getString("baseUrl", "http://10.0.2.2:8080"))
        }
        dashboard.addView(baseUrlInput)
        dashboard.addView(Button(this).apply {
            text = "حفظ الرابط"
            setOnClickListener {
                getPreferences(Context.MODE_PRIVATE).edit().putString("baseUrl", baseUrlInput.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "تم الحفظ", Toast.LENGTH_SHORT).show()
            }
        })
        dashboard.addView(Button(this).apply {
            text = "👤 ملف الوكيل"
            setOnClickListener { showProfile() }
        })
        dashboard.addView(Button(this).apply {
            text = "🛡️ صلاحيات الأدوات"
            setOnClickListener { showToolPermissions() }
        })
        dashboard.addView(Button(this).apply {
            text = "📋 سجل العمليات"
            setOnClickListener { showLogs() }
        })
        dashboard.addView(Button(this).apply {
            text = "🗑️ مسح السجل"
            setOnClickListener {
                logStore.clear()
                Toast.makeText(this@MainActivity, "تم مسح السجل", Toast.LENGTH_SHORT).show()
            }
        })
        dashboard.addView(Button(this).apply {
            text = "ℹ️ عن أبو ليث Agent"
            setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle("أبو ليث Agent — الإصدار 1.0.0")
                    .setMessage("مركز تحكم موحد للوكيل: طلبات، مهام، صلاحيات، وسجل عمليات. التنفيذ الخارجي لا يتم إلا بعد موافقتك.")
                    .setPositiveButton("حسناً", null).show()
            }
        })
    }

    private fun addCard(title: String, body: String) {
        dashboard.addView(TextView(this).apply {
            text = "$title\n$body"
            textSize = 17f
            setPadding(18, 18, 18, 18)
        })
    }

    private fun askAgentDialog() {
        val input = EditText(this).apply { hint = "مثال: افتح https://example.com" }
        AlertDialog.Builder(this)
            .setTitle("طلب جديد")
            .setView(input)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("إرسال") { _, _ -> runAgentNow(input.text.toString().trim()) }
            .show()
    }

    private fun showTaskDialog(existing: AgentTask?) {
        val title = EditText(this).apply {
            hint = "مثال: راقب أخبار الذكاء الاصطناعي"
            setText(existing?.title ?: "")
        }
        val choices = arrayOf("مرة واحدة بعد دقيقة", "يومية")
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, choices)
            setSelection(if (existing?.schedule == "DAILY") 1 else 0)
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 10, 30, 0)
            addView(title)
            addView(spinner)
        }
        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "إضافة مهمة" else "تعديل المهمة")
            .setView(container)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ") { _, _ ->
                val task = existing ?: AgentTask(title = "", schedule = "ONCE")
                task.title = title.text.toString().trim().ifBlank { "مهمة بدون اسم" }
                task.schedule = if (spinner.selectedItemPosition == 1) "DAILY" else "ONCE"
                task.enabled = true
                store.save(task)
                enqueue(task, 1)
                showTasks()
            }.show()
    }

    private fun runAgentNow(task: String) {
        val base = getPreferences(Context.MODE_PRIVATE).getString("baseUrl", "http://10.0.2.2:8080") ?: ""
        Thread {
            try {
                val result = AgentApi.run(base, task)
                runOnUiThread {
                    if (result.actions.isNotEmpty()) result.actions.forEach { executeWithApproval(it) }
                    else AlertDialog.Builder(this).setTitle("نتيجة الوكيل").setMessage(result.output).setPositiveButton("حسناً", null).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "خطأ: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun executeWithApproval(action: AgentAction) {
        if (!isToolAllowed(action.name)) {
            logStore.add(OperationLog(action = action.name, details = action.args.toString(), status = "مرفوض — الأداة متوقفة"))
            Toast.makeText(this, "الأداة غير مفعّلة", Toast.LENGTH_LONG).show()
            return
        }
        val description = when (action.name) {
            "open_url" -> "فتح الرابط:\n${action.args.optString("url")}"
            "share_text" -> "فتح شاشة المشاركة بالنص:\n${action.args.optString("text")}"
            "create_text_file" -> "إنشاء ملف نصي باسم:\n${action.args.optString("filename")}"
            else -> "تنفيذ الإجراء: ${action.name}"
        }
        logStore.add(OperationLog(action = action.name, details = description, status = "بانتظار الموافقة"))
        AlertDialog.Builder(this)
            .setTitle("🛡️ موافقة مطلوبة")
            .setMessage(description)
            .setNegativeButton("رفض") { _, _ ->
                logStore.add(OperationLog(action = action.name, details = description, status = "مرفوض"))
            }
            .setPositiveButton("سماح") { _, _ ->
                logStore.add(OperationLog(action = action.name, details = description, status = "موافق عليه"))
                performAction(action)
            }.show()
    }

    private fun isToolAllowed(name: String) =
        getPreferences(Context.MODE_PRIVATE).getBoolean("tool_$name", true)

    private fun showProfile() {
        val prefs = getSharedPreferences("agent_profile", Context.MODE_PRIVATE)
        val name = EditText(this).apply {
            hint = "اسم العرض (اختياري)"
            setText(prefs.getString("display_name", "") ?: "")
        }
        AlertDialog.Builder(this)
            .setTitle("👤 ملف الوكيل")
            .setMessage("يُحفظ هذا الملف محلياً على الجهاز ولا يحتاج بيانات حساسة.")
            .setView(name)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ") { _, _ ->
                prefs.edit().putString("display_name", name.text.toString().trim()).apply()
                Toast.makeText(this, "تم حفظ الملف محلياً", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showToolPermissions() {
        val names = arrayOf("open_url", "share_text", "create_text_file")
        val labels = arrayOf("فتح الروابط", "المشاركة", "إنشاء الملفات")
        val checked = BooleanArray(names.size) { isToolAllowed(names[it]) }
        AlertDialog.Builder(this)
            .setTitle("صلاحيات أدوات الوكيل")
            .setMultiChoiceItems(labels, checked) { _, which, enabled ->
                getPreferences(Context.MODE_PRIVATE).edit().putBoolean("tool_${names[which]}", enabled).apply()
                logStore.add(OperationLog(action = names[which], details = labels[which], status = if (enabled) "تم التفعيل" else "تم الإيقاف"))
            }
            .setPositiveButton("إغلاق", null).show()
    }

    private fun showLogs() {
        val logs = logStore.all()
        val text = if (logs.isEmpty()) "لا توجد عمليات مسجلة." else logs.take(50).joinToString("\n\n") {
            "⏱ ${logStore.formatTime(it.timestamp)}\n🔧 ${it.action}\n📌 ${it.status}\n${it.details}"
        }
        AlertDialog.Builder(this)
            .setTitle("📋 سجل العمليات")
            .setMessage(text)
            .setNegativeButton("مسح") { _, _ -> logStore.clear(); Toast.makeText(this, "تم المسح", Toast.LENGTH_SHORT).show() }
            .setPositiveButton("إغلاق", null).show()
    }

    private fun performAction(action: AgentAction) {
        try {
            when (action.name) {
                "open_url" -> {
                    val raw = action.args.optString("url")
                    val uri = Uri.parse(raw)
                    if (uri.scheme != "http" && uri.scheme != "https") error("الرابط غير مسموح")
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    logStore.add(OperationLog(action = action.name, details = raw, status = "تم التنفيذ"))
                }
                "share_text" -> {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, action.args.optString("text"))
                    }
                    startActivity(Intent.createChooser(send, "مشاركة عبر"))
                    logStore.add(OperationLog(action = action.name, details = action.args.optString("text"), status = "تم التنفيذ"))
                }
                "create_text_file" -> {
                    val name = action.args.optString("filename").ifBlank { "agent-note.txt" }
                        .replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val dir = File(filesDir, "agent_files").apply { mkdirs() }
                    File(dir, name).writeText(action.args.optString("content"), Charsets.UTF_8)
                    logStore.add(OperationLog(action = action.name, details = name, status = "تم التنفيذ"))
                    Toast.makeText(this, "تم إنشاء الملف داخل مساحة التطبيق", Toast.LENGTH_LONG).show()
                }
                else -> Toast.makeText(this, "إجراء غير معروف", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            logStore.add(OperationLog(action = action.name, details = e.message ?: "خطأ", status = "فشل التنفيذ"))
            Toast.makeText(this, "تعذر التنفيذ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun enqueue(task: AgentTask, delayMinutes: Long) {
        val base = getPreferences(Context.MODE_PRIVATE).getString("baseUrl", "http://10.0.2.2:8080") ?: ""
        val data = workDataOf("taskId" to task.id, "taskText" to task.title, "baseUrl" to base)
        if (task.schedule == "DAILY") {
            val req = PeriodicWorkRequestBuilder<AgentWorker>(24, TimeUnit.HOURS).setInputData(data).build()
            WorkManager.getInstance(this).enqueueUniquePeriodicWork("agent-${task.id}", ExistingPeriodicWorkPolicy.UPDATE, req)
        } else {
            val req = OneTimeWorkRequestBuilder<AgentWorker>().setInputData(data).setInitialDelay(delayMinutes, TimeUnit.MINUTES).build()
            WorkManager.getInstance(this).enqueueUniqueWork("agent-${task.id}", ExistingWorkPolicy.REPLACE, req)
        }
        Toast.makeText(this, "تمت جدولة المهمة", Toast.LENGTH_SHORT).show()
    }

    private fun cancel(task: AgentTask) =
        WorkManager.getInstance(this).cancelUniqueWork("agent-${task.id}")

    private fun requestNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
    }
}
