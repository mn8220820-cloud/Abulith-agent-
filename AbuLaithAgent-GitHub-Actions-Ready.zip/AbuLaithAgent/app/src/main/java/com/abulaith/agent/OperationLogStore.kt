
package com.abulaith.agent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class OperationLog(
    val id: String = UUID.randomUUID().toString(),
    val action: String,
    val details: String,
    val status: String,
    val timestamp: Long = System.currentTimeMillis()
)

class OperationLogStore(context: Context) {
    private val prefs = context.getSharedPreferences("operation_log", Context.MODE_PRIVATE)

    fun all(): MutableList<OperationLog> {
        val arr = JSONArray(prefs.getString("items", "[]") ?: "[]")
        val out = mutableListOf<OperationLog>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out += OperationLog(
                id = o.getString("id"),
                action = o.getString("action"),
                details = o.getString("details"),
                status = o.getString("status"),
                timestamp = o.optLong("timestamp", System.currentTimeMillis())
            )
        }
        return out.sortedByDescending { it.timestamp }.toMutableList()
    }

    fun add(log: OperationLog) {
        val list = all()
        list.add(0, log)
        persist(list.take(100))
    }

    fun clear() = prefs.edit().remove("items").apply()

    fun formatTime(ts: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(ts))

    private fun persist(list: List<OperationLog>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("action", it.action)
                put("details", it.details)
                put("status", it.status)
                put("timestamp", it.timestamp)
            })
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
