
package com.abulaith.agent

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class PendingApproval(
    val id: String = UUID.randomUUID().toString(),
    val action: AgentAction,
    val createdAt: Long = System.currentTimeMillis()
)

class ApprovalStore(context: Context) {
    private val prefs = context.getSharedPreferences("approvals", Context.MODE_PRIVATE)

    fun all(): MutableList<PendingApproval> {
        val arr = JSONArray(prefs.getString("items", "[]") ?: "[]")
        val out = mutableListOf<PendingApproval>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out += PendingApproval(
                o.getString("id"),
                AgentAction(o.getString("callId"), o.getString("name"), JSONObject(o.getString("args"))),
                o.optLong("createdAt", System.currentTimeMillis())
            )
        }
        return out
    }

    fun add(action: AgentAction) {
        val list = all()
        list += PendingApproval(action = action)
        persist(list.takeLast(50))
    }

    fun remove(id: String) = persist(all().filterNot { it.id == id })

    fun clear() = prefs.edit().remove("items").apply()

    private fun persist(list: List<PendingApproval>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("callId", it.action.callId)
                put("name", it.action.name)
                put("args", it.action.args.toString())
                put("createdAt", it.createdAt)
            })
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
