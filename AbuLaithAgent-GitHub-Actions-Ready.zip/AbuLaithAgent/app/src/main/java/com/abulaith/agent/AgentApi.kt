
package com.abulaith.agent

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class AgentAction(val callId: String, val name: String, val args: JSONObject)
data class AgentResult(val output: String, val requiresApproval: Boolean, val actions: List<AgentAction>)

object AgentApi {
    fun run(baseUrl: String, task: String, history: List<ChatMessage> = emptyList()): AgentResult {
        val url = URL(baseUrl.trimEnd('/') + "/api/agent")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")

        val h = JSONArray()
        history.takeLast(20).forEach {
            h.put(JSONObject().put("role", it.role).put("text", it.text))
        }
        val body = JSONObject().put("message", task).put("history", h).toString()
        conn.outputStream.use { it.write(body.toByteArray()) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (conn.responseCode !in 200..299) error(text)
        val obj = JSONObject(text)
        val arr = obj.optJSONArray("actions") ?: JSONArray()
        val actions = mutableListOf<AgentAction>()
        for (i in 0 until arr.length()) {
            val a = arr.getJSONObject(i)
            actions += AgentAction(a.getString("callId"), a.getString("name"), a.optJSONObject("arguments") ?: JSONObject())
        }
        return AgentResult(obj.optString("output", ""), obj.optBoolean("requiresApproval", false), actions)
    }
}
